//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package company;

enum Status {
    SUSPENDED,
    PENDING,
    ACTIVE;

    private Status() {
    }
}
