//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package company;

public interface Regist {
    Boolean isValid(personInfo var1);

    personInfo regist(String var1, String var2, String var3, String var4, String var5);

    personInfo regist(String var1, String var2, String var3, String var4);
}
