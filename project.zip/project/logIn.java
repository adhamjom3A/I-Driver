package company;

public interface logIn extends Regist {

}
