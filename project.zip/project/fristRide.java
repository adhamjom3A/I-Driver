package company;

public class fristRide extends rideDiscounts{
    public fristRide(ridePrice r) {
        super(r);
    }
    @Override
    public int getPrice(){
        return super.getPrice()-(super.getPrice()/10);
    }
}
