package company;

public interface ridePrice {
    public int getRidePrice();
}
